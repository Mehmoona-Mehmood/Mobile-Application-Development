import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import CategoryCard from '../components/CategoryCard';
//for styling
import GlobalStyles from '../styles/GlobalStyles'; 

const PerfumesScreen = ({ navigation }) => {
  const subcategories = [
    {
      id: 1,
      title: 'Men',
      image: require('../../assets/men-perfumes.jpeg'),
      screen: 'MenPerfume',
    },
    {
      id: 2,
      title: 'Women',
      image: require('../../assets/women-perfumes.jpeg'),
      screen: 'WomenPerfume',
    },
  ];

  return (
    <ScrollView style={GlobalStyles.container}>
      <Text style={GlobalStyles.header}>Perfumes Collection</Text>
      <Text style={GlobalStyles.description}>
        Find your signature scent from our exclusive perfume collection
      </Text>
      
      <View style={GlobalStyles.categories}>
        {subcategories.map((category) => (
          <CategoryCard
            key={category.id}
            title={category.title}
            image={category.image}
            onPress={() => navigation.navigate(category.screen)}
          />
        ))}
      </View>
    </ScrollView>
  );
};



export default PerfumesScreen;