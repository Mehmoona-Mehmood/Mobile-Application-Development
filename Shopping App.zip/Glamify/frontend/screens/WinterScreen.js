import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import CategoryCard from '../components/CategoryCard';
import GlobalStyles from '../styles/GlobalStyles';

const WinterScreen = ({ navigation }) => {
  const subcategories = [
    {
      id: 1,
      title: 'Pret',
      image: require('../../assets/winter-pret.jpeg'),
      screen: 'PretWinter',
    },
    {
      id: 2,
      title: 'Unstitched',
      image: require('../../assets/winter-unst.jpeg'),
      screen: 'UnstitchedWinter',
    },
  ];

  return (
    <ScrollView style={GlobalStyles.container}>
      <Text style={GlobalStyles.header}>Winter Collection</Text>
      <Text style={GlobalStyles.description}>
        Stay warm and stylish with our exclusive winter collection
      </Text>
      
      <View style={GlobalStyles.categories}>
        {subcategories.map((category) => (
          <CategoryCard
            key={category.id}
            title={category.title}
            image={category.image}
            onPress={() => navigation.navigate(category.screen)}
          />
        ))}
      </View>
    </ScrollView>
  );
};


export default WinterScreen;