import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import CategoryCard from '../components/CategoryCard';
import GlobalStyles from '../styles/GlobalStyles';

const SummerScreen = ({ navigation }) => {
  const subcategories = [
    {
      id: 1,
      title: 'Pret',
      image: require('../../assets/summer-pret.jpeg'),
      screen: 'PretSummer',
    },
    {
      id: 2,
      title: 'Unstitched',
      image: require('../../assets/su-unstitched.jpg'),
      screen: 'UnstitchedSummer',
    },
  ];

  return (
    <ScrollView style={GlobalStyles.container}>
      <Text style={GlobalStyles.header}>Summer Collection</Text>
      <Text style={GlobalStyles.description}>
        Beat the heat with our trendy and comfortable summer wear
      </Text>
      
      <View style={GlobalStyles.categories}>
        {subcategories.map((category) => (
          <CategoryCard
            key={category.id}
            title={category.title}
            image={category.image}
            onPress={() => navigation.navigate(category.screen)}
          />
        ))}
      </View>
    </ScrollView>
  );
};



export default SummerScreen;