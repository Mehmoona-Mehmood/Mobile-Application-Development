import React, { useRef, useEffect } from 'react';
import { View, Text, ScrollView, StyleSheet, Image, TouchableOpacity, Animated } from 'react-native';
import CategoryCard from '../components/CategoryCard';
//for accessing the global styling sheet
import GlobalStyles from '../styles/GlobalStyles';

const HomeScreen = ({ navigation }) => {
  const categories = [
    {
      id: 1,
      title: 'Winter Collection',
      image: require('../../assets/winter-collection.jpg'),
      screen: 'Winter',
    },
    {
      id: 2,
      title: 'Summer Collection',
      image: require('../../assets/summer-collection.png'),
      screen: 'Summer',
    },
    {
      id: 3,
      title: 'Perfumes',
      image: require('../../assets/perfumes.jpeg'),
      screen: 'Perfumes',
    },
    {
      id: 4,
      title: 'Sale',
      image: require('../../assets/sale.jpeg'),
      screen: 'Sale',
    },
  ];

  // Animation for Shop Now button
  const buttonScale = useRef(new Animated.Value(1)).current;
  const buttonOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Button fade in and pulse animation
    Animated.sequence([
      Animated.timing(buttonOpacity, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.loop(
        Animated.sequence([
          Animated.timing(buttonScale, {
            toValue: 1.1,
            duration: 800,
            useNativeDriver: true,
          }),
          Animated.timing(buttonScale, {
            toValue: 1,
            duration: 800,
            useNativeDriver: true,
          }),
        ])
      ),
    ]).start();
  }, []);

  const handleShopNow = () => {
    // Navigate to Sale screen when Shop Now pressed
    navigation.navigate('Sale');
  };

  return (
    <ScrollView style={GlobalStyles.container}>
      <Text style={GlobalStyles.header}>Welcome to Glamify</Text>
      <Text style={GlobalStyles.subHeader}>Discover the latest fashion trends</Text>
      
      {/* Horizontal Banner with Shop Now Button */}
      <View style={GlobalStyles.bannerContainer}>
        <Image 
          source={require('../../assets/sale.jpg')} // Add your horizontal banner image
          style={GlobalStyles.bannerImage}
          resizeMode="cover"
        />
        <View style={GlobalStyles.bannerOverlay} />
        <Animated.View 
          style={[
            GlobalStyles.buttonContainer,
            {
              opacity: buttonOpacity,
              transform: [{ scale: buttonScale }]
            }
          ]}
        >
          <TouchableOpacity style={GlobalStyles.shopNowButton} onPress={handleShopNow}>
            <Text style={GlobalStyles.shopNowText}>SHOP NOW</Text>
          </TouchableOpacity>
        </Animated.View>
      </View>
      
      
      <View style={GlobalStyles.categories}>
        {categories.map((category) => (
          <CategoryCard
            key={category.id}
            title={category.title}
            image={category.image}
            onPress={() => navigation.navigate(category.screen)}
          />
        ))}
      </View>
    </ScrollView>
  );
};


export default HomeScreen;