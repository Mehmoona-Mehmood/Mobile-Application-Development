import React from 'react';
import { View, Text, ScrollView, StyleSheet } from 'react-native';
import ProductCard from '../../components/ProductCard';
import GlobalStyles from '../../styles/GlobalStyles';

const MenPerfumeScreen = () => {
  const products = [
    {
      id: 1,
      name: 'Woody Elegance',
      price: 4000,
      image: require('../../../assets/per1.jpeg'),
      description: 'Rich woody notes with musk undertones'
    },
    {
      id: 2,
      name: 'Fresh Citrus',
      price: 5000,
      image: require('../../../assets/per2.jpeg'),
      description: 'Zesty citrus with herbal accents'
    },
    {
      id: 3,
      name: 'Midnight Oud',
      price: 3500,
      image: require('../../../assets/per3.jpeg'),
      description: 'Luxurious oud with spicy notes'
    },
    {
      id: 4,
      name: 'Ocean Breeze',
      price: 8000,
      image: require('../../../assets/per4.jpeg'),
      description: 'Fresh aquatic scent for everyday wear'
    },
    {
      id: 5,
      name: 'Leather & Tobacco',
      price: 4500,
      image: require('../../../assets/per5.jpeg'),
      description: 'Bold leather with warm tobacco notes'
    },
    {
      id: 6,
      name: 'Sport Energy',
      price: 6000,
      image: require('../../../assets/per6.jpeg'),
      description: 'Energetic scent for active lifestyle'
    },
  ];

  const handleAddToCart = (productName) => {
    alert(`${productName} added to cart!`);
  };

  return (
    <ScrollView style={GlobalStyles.container}>
      <Text style={GlobalStyles.header}>Men's Perfume Collection</Text>
      <Text style={GlobalStyles.description}>
        Discover masculine fragrances that make a statement
      </Text>
      
      <View style={GlobalStyles.statsContainer}>
        <View style={GlobalStyles.statItem}>
          <Text style={GlobalStyles.statNumber}>{products.length}</Text>
          <Text style={GlobalStyles.statLabel}>Products</Text>
        </View>
        <View style={GlobalStyles.statItem}>
          <Text style={GlobalStyles.statNumber}>Rs 3500+</Text>
          <Text style={GlobalStyles.statLabel}>Starting Price</Text>
        </View>
        <View style={GlobalStyles.statItem}>
          <Text style={GlobalStyles.statNumber}>⭐ 4.8</Text>
          <Text style={GlobalStyles.statLabel}>Rating</Text>
        </View>
      </View>

      <View style={GlobalStyles.products}>
        {products.map((product) => (
          <View key={product.id} style={GlobalStyles.productWrapper}>
            <ProductCard
              name={product.name}
              price={product.price}
              image={product.image}
              onAddToCart={() => handleAddToCart(product.name)}
            />
            <Text style={GlobalStyles.productDescription}>{product.description}</Text>
          </View>
        ))}
      </View>
    </ScrollView>
  );
};


export default MenPerfumeScreen;