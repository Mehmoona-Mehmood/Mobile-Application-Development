import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';

const CategoryCard = ({ title, image, onPress }) => {
  return (
    <TouchableOpacity style={styles.card} onPress={onPress}>
      <Image source={image} style={styles.image} />
      <View style={styles.overlay} />
      <Text style={styles.title}>{title}</Text>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    width: 150,
    height: 150,
    margin: 10,
    borderRadius: 10,
    overflow: 'hidden',
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  title: {
    position: 'absolute',
  bottom: 15,                    // ← Bottom position adjust
  left: 0,
  right: 0,
  color: 'white',
  fontSize: 16,                  // ← Size increase
  fontWeight: 'bold',
  fontFamily: 'Allura-Regular',       // ← Custom font
  textAlign: 'center',
  paddingHorizontal: 8,
  textShadowColor: 'rgba(0, 0, 0, 0.9)',
  textShadowOffset: { width: 2, height: 2 },
  textShadowRadius: 5,
  letterSpacing: 0.5,           // ← Letter spacing
  },
});

export default CategoryCard;