import { StyleSheet } from 'react-native';

const GlobalStyles = StyleSheet.create({
  // Common Container Styles
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa',
    padding: 20,
  },


  // Header Styles
  header: {
    fontSize: 30,
    fontFamily: 'Aqbalamo',
    textAlign: 'center',
    marginTop: 30,
    marginBottom: 10,
    color: '#ff6b6b',
    textShadowColor: 'rgba(255, 107, 107, 0.3)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 5,
    letterSpacing: 1,
  },

  // Sub Header/Description Styles
  subHeader: {
    fontSize: 14,
    fontFamily: 'Allura-Regular',
    textAlign: 'center',
    marginBottom: 20,
    color: '#666',
    fontStyle: 'italic',
    lineHeight: 28,
  },

  description: {
    fontSize: 14,                    
    fontFamily: 'Allura-Regular',    // Allura font for description
    textAlign: 'center',
    marginBottom: 30,
    color: '#666',
    fontStyle: 'italic',
    lineHeight: 28,
  },

   //Category Container styling
  categoriesTitle: {
    fontSize: 22,
    fontFamily: 'Aqbalamo',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },

  categories: {
    flexDirection: 'row',
    justifyContent: 'center',        // ← Cards center align
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 20, 
  },


  // Products Container Styles
  //For the sales category
 products: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },

  productWrapper: {
  width: '48%',
  maxWidth: 200, 
  marginBottom: 15,
},

  

  // Stats Container Styles for the perfumes subcategories
  statsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 3,
  },

  statItem: {
    alignItems: 'center',
  },

  statNumber: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ff6b6b',
  },


  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 5,
  },

  // Product Description Styles
  productDescription: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
    marginTop: 5,
    paddingHorizontal: 5,
  },

  // Banner Styles for home screen
  bannerContainer: {
    height: 180,
    marginHorizontal: 20,
    marginBottom: 30,
    borderRadius: 15,
    overflow: 'hidden',
    position: 'relative',
  },

  bannerImage: {
   width: '100%',
    height: '100%',
  },

  bannerOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },

  // Button Styles 
 buttonContainer: {
    position: 'absolute',
    bottom: 20,
    alignSelf: 'center',
  },

  shopNowButton: {
    backgroundColor: '#ff6b6b',
    paddingHorizontal: 30,
    paddingVertical: 12,
    borderRadius: 25,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 8,
  },

  shopNowText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
    letterSpacing: 1,
  },


  //Category for home page
  categoriesTitle: {
    fontSize: 22,
    fontFamily: 'Aqbalamo',
    textAlign: 'center',
    marginBottom: 20,
    color: '#333',
  },

  categories: {
    flexDirection: 'row',
    justifyContent: 'center',        // ← Cards center align
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 20, 
  },

  // Text Styles
  textCenter: {
    textAlign: 'center',
  },

  textBold: {
    fontWeight: 'bold',
  },

  textPrimary: {
    color: '#ff6b6b',
  },

  textSecondary: {
    color: '#666',
  },

  textWhite: {
    color: 'white',
  },

});

export default GlobalStyles;