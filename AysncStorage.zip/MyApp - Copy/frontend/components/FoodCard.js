import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function FoodCard({ name, price }) {
  return (
    <View style={styles.card}>
      <Text style={styles.foodName}>{name}</Text>
      <Text style={styles.foodPrice}>{price}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  card: { backgroundColor: '#ffe5b4', padding: 15, marginBottom: 10, borderRadius: 10 },
  foodName: { fontSize: 18, fontWeight: 'bold' },
  foodPrice: { fontSize: 16, color: '#555' },
});


