import React, { useState, useEffect } from 'react';
import {
View,
Text,
FlatList,
ActivityIndicator,
StyleSheet
} from 'react-native';

const MovieScreen = () => {
// Step 1: useState for data and loading
const [movies, setMovies] = useState([]);
const [loading, setLoading] = useState(true);

// Step 2: useEffect for fetching data once
useEffect(() => {
fetchMovies();
}, []);

const fetchMovies = async () => {
try {
const response = await fetch('https://reactnative.dev/movies.json');
const jsonData = await response.json();
setMovies(jsonData.movies); // API se movies array mil raha hai
setLoading(false);
} catch (error) {
console.error('Error fetching movies:', error);
setLoading(false);
}
};

// Movie item display karne ke liye
const renderMovieItem = ({ item }) => (
<View style={styles.movieItem}>
<Text style={styles.title}>{item.title}</Text>
<Text style={styles.year}>Release Year: {item.releaseYear}</Text>
</View>
);

// Step 3: Loader show karein
if (loading) {
return (
<View style={styles.loaderContainer}>
<ActivityIndicator size="large" color="#0000ff" />
<Text>Loading movies...</Text>
</View>
);
}

// Step 4: Movies list show karein with FlatList
return (
<View style={styles.container}>
<Text style={styles.header}>Movies List</Text>
<FlatList
data={movies}
renderItem={renderMovieItem}
keyExtractor={(item) => item.id}
showsVerticalScrollIndicator={false}
/>
</View>
);
};

const styles = StyleSheet.create({
container: {
flex: 1,
padding: 20,
backgroundColor: '#df8edfff',
},
loaderContainer: {
flex: 1,
justifyContent: 'center',
alignItems: 'center',
},
header: {
fontSize: 24,
fontWeight: 'bold',
marginBottom: 20,
textAlign: 'center',
},
movieItem: {
padding: 15,
borderBottomWidth: 1,
borderBottomColor: '#ccc',
marginBottom: 10,
backgroundColor: '#f9f9f9',
borderRadius: 8,
},
title: {
fontSize: 18,
fontWeight: 'bold',
color: '#333',
},
year: {
fontSize: 14,
color: '#666',
marginTop: 5,
},
});

export default MovieScreen;