import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ScrollView } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function StorageScreen() {
  const [keyInput, setKeyInput] = useState('');
  const [valueInput, setValueInput] = useState('');
  const [storeMsg, setStoreMsg] = useState('');
  const [fetchMsg, setFetchMsg] = useState('');
  const [deleteMsg, setDeleteMsg] = useState('');
  const [fetchedValue, setFetchedValue] = useState('');
  const [allData, setAllData] = useState([]); // 🆕 to store all saved data

  // ✅ 1. Store Data
  const storeData = async () => {
    if (!keyInput || !valueInput) {
      setStoreMsg('⚠️ Please enter both key and value.');
      return;
    }
    try {
      await AsyncStorage.setItem(keyInput, valueInput);
      setStoreMsg(`✅ Stored successfully for key "${keyInput}"`);
    } catch (e) {
      console.log(e);
      setStoreMsg('❌ Failed to store data.');
    }
  };

  // ✅ 2. Fetch Data
  const fetchData = async () => {
    if (!keyInput) {
      setFetchMsg('⚠️ Please enter a key to fetch data.');
      return;
    }
    try {
      const value = await AsyncStorage.getItem(keyInput);
      if (value !== null) {
        setFetchedValue(value);
        setFetchMsg(`🔍 Data found for key "${keyInput}"`);
      } else {
        setFetchedValue('');
        setFetchMsg('⚠️ No data found for this key.');
      }
    } catch (e) {
      console.log(e);
      setFetchMsg('❌ Failed to fetch data.');
    }
  };

  // ✅ 3. Remove Data
  const removeData = async () => {
    if (!keyInput) {
      setDeleteMsg('⚠️ Please enter a key to delete data.');
      return;
    }
    try {
      await AsyncStorage.removeItem(keyInput);
      setFetchedValue('');
      setDeleteMsg(`🗑️ Data removed for key "${keyInput}"`);
    } catch (e) {
      console.log(e);
      setDeleteMsg('❌ Failed to delete data.');
    }
  };

  // 🆕 4. Show All Saved Data
  const showAllData = async () => {
    try {
      const keys = await AsyncStorage.getAllKeys(); // get all keys
      const stores = await AsyncStorage.multiGet(keys); // get all key-value pairs
      setAllData(stores); // save in state
    } catch (e) {
      console.log(e);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>📦 AsyncStorage</Text>

      {/* Input fields */}
      <TextInput
        style={styles.input}
        placeholder="Enter key (e.g., userToken)"
        value={keyInput}
        onChangeText={setKeyInput}
      />
      <TextInput
        style={styles.input}
        placeholder="Enter value (e.g., 12345)"
        value={valueInput}
        onChangeText={setValueInput}
      />

      {/* Store Section */}
      <Button title="Store Data" onPress={storeData} color="#ff914d" />
      {storeMsg ? <Text style={styles.msg}>{storeMsg}</Text> : null}

      {/* Fetch Section */}
      <View style={{ marginVertical: 10 }} />
      <Button title="Fetch Data" onPress={fetchData} color="#ff914d" />
      {fetchMsg ? <Text style={styles.msg}>{fetchMsg}</Text> : null}
      {fetchedValue ? (
        <Text style={styles.value}>Fetched Value: {fetchedValue}</Text>
      ) : null}

      {/* Delete Section */}
      <View style={{ marginVertical: 10 }} />
      <Button title="Remove Data" onPress={removeData} color="#ff914d" />
      {deleteMsg ? <Text style={styles.msg}>{deleteMsg}</Text> : null}

      {/* 🆕 Show All Saved Data */}
      <View style={{ marginVertical: 15 }} />
      <Button title="Show All Saved Data" onPress={showAllData} color="#4caf50" />

      {allData.length > 0 && (
        <View style={{ marginTop: 10 }}>
          <Text style={{ fontSize: 18, fontWeight: 'bold', textAlign: 'center' }}>
            🧾 All Saved Data:
          </Text>
          {allData.map(([key, value], index) => (
            <Text key={index} style={styles.value}>
              🔑 {key} : {value}
            </Text>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    marginTop: 40,
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    marginBottom: 10,
    padding: 10,
    borderRadius: 8,
  },
  msg: {
    marginTop: 5,
    fontSize: 15,
    color: '#333',
    fontStyle: 'italic',
  },
  value: {
    marginTop: 5,
    fontSize: 16,
    fontWeight: '600',
    color: '#111',
  },
});
