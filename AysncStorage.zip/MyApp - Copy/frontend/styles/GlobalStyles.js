import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  // Container Styles
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff'
  },
  
  containerWithPadding: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff'
  },

  // Text Styles
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 20
  },

  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10
  },

  buttonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 16
  },

  foodName: {
    fontSize: 18,
    fontWeight: 'bold'
  },

  foodPrice: {
    fontSize: 16,
    color: '#555',
    marginBottom: 5
  },

  orderHeader: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 5
  },

  // Input Styles
  input: {
    width: '80%',
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    borderRadius: 10,
    marginBottom: 15
  },

  // Button Styles
  button: {
    backgroundColor: '#ff914d',
    padding: 12,
    borderRadius: 10,
    width: '60%',
    alignItems: 'center'
  },

  // Food Item Styles
  foodContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
    backgroundColor: '#f9f9f9',
    borderRadius: 10,
    padding: 10,
    elevation: 2,
  },

  foodImage: {
    width: 80,
    height: 80,
    borderRadius: 10
  },

  foodInfo: {
    marginLeft: 15,
    flex: 1
  },

  // Order Summary Styles
  orderSummary: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#f0f0f0',
    borderRadius: 10
  },

  // Cart Item Styles
  cartItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: 10,
    borderBottomWidth: 1,
    borderColor: '#ccc',
  },

  // Card Styles
  card: {
    backgroundColor: '#ffe5b4',
    padding: 15,
    marginBottom: 10,
    borderRadius: 10
  }
});