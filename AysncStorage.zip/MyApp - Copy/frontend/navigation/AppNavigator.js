
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from '../screens/HomeScreen';
import AsyncStorageScreen from '../screens/AsyncStorageScreen';
import MovieScreen from '../screens/MovieScreen';

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
return (
<NavigationContainer>
<Stack.Navigator initialRouteName="Home">
<Stack.Screen name="Home" component={HomeScreen} />
<Stack.Screen name="AsyncStorage" component={AsyncStorageScreen} />
<Stack.Screen name="Movies" component={MovieScreen} />
</Stack.Navigator>
</NavigationContainer>
);
}
