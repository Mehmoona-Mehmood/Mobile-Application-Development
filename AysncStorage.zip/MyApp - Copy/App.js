import React from 'react';
import AppNavigator from './frontend/navigation/AppNavigator';

export default function App() {
  return <AppNavigator />;
}



